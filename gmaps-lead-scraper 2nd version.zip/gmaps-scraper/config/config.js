const path = require('path');

module.exports = {
  server: {
    port: process.env.PORT || 3000,
  },
  chrome: {
    // Chrome must be launched by the user with remote debugging enabled.
    // e.g. chrome.exe --remote-debugging-port=9222
    cdpUrl: process.env.CDP_URL || 'http://localhost:9222',
  },
  scraper: {
    // Max time to wait for the results feed / business panel to load
    navigationTimeoutMs: 15000,
    // Time to wait for the panel to settle after clicking a business
    businessLoadDelayMs: 900,
    // Delay between scroll actions on the results feed
    scrollDelayMs: 700,
    // How many consecutive scrolls with no new results before we consider the feed "done"
    maxStagnantScrolls: 4,
    // Retry a failed business extraction this many times before skipping
    maxRetries: 1,
    // Website analysis timeout
    websiteTimeoutMs: 10000,
  },
  paths: {
    dataDir: path.join(__dirname, '..', 'data'),
    exportsDir: path.join(__dirname, '..', 'data', 'exports'),
    progressFile: path.join(__dirname, '..', 'data', 'progress.json'),
  },
};
