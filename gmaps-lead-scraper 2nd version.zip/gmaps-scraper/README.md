# Google Maps Lead Scraper

A semi-automated lead generation tool. **You** manually search Google Maps in
your own Chrome browser; this app connects to that already-open browser over
the Chrome DevTools (CDP) protocol, scrolls and opens each result, extracts
business details, and exports everything to Excel/CSV.

> **Please note:** Automated collection of data from Google Maps is against
> Google's Terms of Service. This tool is intended for your own manual,
> small-scale research use. You are responsible for how you use it and for
> complying with the terms of any site you point it at.

---

## How it works

1. **You** open Google Chrome yourself (with remote debugging enabled — see
   below), open Google Maps, and search for whatever you want
   (e.g. "Cafe Sangamner"). You stay on that results page.
2. **The app** connects to that Chrome window, finds the Maps tab, scrolls
   the results list, opens each business, extracts its details, and returns
   to the list — repeating until every result has been processed.
3. **You** click "Export Excel" or "Export CSV" to download the leads.

The app never launches its own browser and never types into or submits the
Google Maps search box — the search itself is always done by you.

---

## Requirements

- Node.js 18 or newer
- Google Chrome installed
- Windows, macOS, or Linux

---

## Installation

```bash
npm install
```

This also runs `playwright install chromium` automatically via the
`postinstall` script (Playwright's bundled Chromium is only used internally
by the library — the app connects to *your* Chrome instance, it does not
launch a new browser window).

---

## Step 1 — Launch Chrome with remote debugging enabled

Close every open Chrome window first, then launch Chrome with the debugging
port open.

**Windows**
```bash
chrome.exe --remote-debugging-port=9222
```
(Run from Command Prompt, PowerShell, or Win+R, using the full path to
`chrome.exe` if it's not on your PATH, typically
`"C:\Program Files\Google\Chrome\Application\chrome.exe"`.)

**macOS**
```bash
/Applications/Google\ Chrome.app/Contents/MacOS/Google\ Chrome --remote-debugging-port=9222
```

**Linux**
```bash
google-chrome --remote-debugging-port=9222
```

In that Chrome window, go to `https://www.google.com/maps`, and run your
search (e.g. "Footwear Shop Pune"). Leave the results open.

---

## Step 2 — Start the app

```bash
npm start
```

Open `http://localhost:3000` in a browser tab (this can be a tab in the same
Chrome window, a different profile, or even a different browser — it's just
the control panel).

---

## Step 3 — Use the app

1. Click **Connect Chrome**. The app will find your Chrome debugging port and
   detect the open Google Maps tab.
   - If it can't reach Chrome, the UI will show the exact command to launch
     Chrome with remote debugging enabled.
2. Click **Scrape Businesses**. Watch live progress, the log window, and the
   estimated time remaining. You can click **Cancel** at any time.
3. Once finished (or partway through), click **Export Excel** or
   **Export CSV** to download your leads file.

Progress is saved to disk after every business (`data/progress.json`), so if
the app crashes or is restarted mid-run, previously scraped results are
reloaded automatically on the next `npm start`.

---

## Output columns

Business Name, Category, Phone, Rating, Reviews, Address, Website, Website
Type, Website Quality, Google Maps Link, Latitude, Longitude, Opening Hours,
Priority, Contacted, Follow-up Date, Deal Status, Notes.

### Website Type
`Website`, `Instagram`, `Facebook`, `WhatsApp`, or `None`.

### Website Quality
`Working` or `Broken` (based on reachability / HTTP status / timeout).

### Priority
- **Very High** — no website, rating > 4.2, reviews > 100
- **High** — Instagram/Facebook/WhatsApp-only presence, or a broken website
- **Medium** — a working but unremarkable website
- **Low** — a working website with strong existing rating/review signals

---

## Project structure

```
gmaps-scraper/
├── package.json
├── README.md
├── config/
│   └── config.js              # timeouts, ports, paths
├── server/
│   ├── index.js                # Express entry point
│   ├── routes/
│   │   └── api.js              # REST + SSE endpoints
│   ├── services/
│   │   ├── browserManager.js   # CDP connection, Maps tab detection
│   │   ├── locatorManager.js   # single source of truth for all page locators
│   │   ├── scraper.js          # scroll/collect/extract orchestration
│   │   ├── websiteAnalyzer.js  # classifies business websites
│   │   ├── priority.js         # lead priority scoring
│   │   ├── exportManager.js    # Excel (ExcelJS) + CSV generation
│   │   └── logger.js           # live log/event bus (used for SSE)
│   └── state/
│       └── scrapeState.js      # in-memory + persisted job state
├── public/
│   ├── index.html
│   ├── css/style.css
│   └── js/app.js
└── data/
    ├── progress.json           # auto-saved after every business (resume support)
    └── exports/                # generated .xlsx / .csv files
```

## Why accessibility locators?

Google Maps' internal CSS class names are auto-generated and change often.
Instead of hard-coding brittle selectors, every element the scraper needs is
defined once in `server/services/locatorManager.js` as an ordered list of
strategies (ARIA role, label, placeholder, ARIA attribute, visible text, then
CSS as a last resort). If one strategy fails, the next is tried automatically,
and the log records which strategy succeeded — so if Google changes its
markup, you only need to add a new strategy in that one file.

## Troubleshooting

- **"Could not connect to Chrome"** — make sure you fully closed all Chrome
  windows before relaunching with `--remote-debugging-port=9222`, and that
  no other app is already using port 9222.
- **"No open Google Maps tab was found"** — open `google.com/maps` in the
  Chrome window you launched with debugging enabled, and run a search first.
- **A business is missing fields** — Maps doesn't show every field for every
  listing (e.g. no phone number or no website). Blank cells are expected and
  the scraper never stops because of this.
