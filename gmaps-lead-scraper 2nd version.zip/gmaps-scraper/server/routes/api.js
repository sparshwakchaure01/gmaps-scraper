const express = require('express');
const path = require('path');
const router = express.Router();

const logger = require('../services/logger');
const state = require('../state/scrapeState');
const browserManager = require('../services/browserManager');
const scraper = require('../services/scraper');
const exportManager = require('../services/exportManager');

// ---------------------------------------------------------------------
// Server-Sent Events stream: live log lines + state patches
// ---------------------------------------------------------------------
router.get('/events', (req, res) => {
  res.set({
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache',
    Connection: 'keep-alive',
  });
  res.flushHeaders();

  res.write(`data: ${JSON.stringify({ type: 'state', state: state.publicSnapshot() })}\n\n`);

  const onEvent = (entry) => {
    res.write(`data: ${JSON.stringify(entry)}\n\n`);
  };
  logger.on('event', onEvent);

  req.on('close', () => {
    logger.removeListener('event', onEvent);
  });
});

router.get('/status', (req, res) => {
  res.json(state.publicSnapshot());
});

// ---------------------------------------------------------------------
// Connect to Chrome + detect Google Maps tab
// ---------------------------------------------------------------------
router.post('/connect', async (req, res) => {
  try {
    await browserManager.connect();
    try {
      await browserManager.findGoogleMapsPage();
    } catch (mapsErr) {
      // Connected to Chrome but no Maps tab yet — not fatal.
      return res.json({
        ok: true,
        chromeConnected: true,
        googleMapsDetected: false,
        message: mapsErr.message,
      });
    }
    return res.json({ ok: true, chromeConnected: true, googleMapsDetected: true });
  } catch (err) {
    return res.status(502).json({
      ok: false,
      error: err.message,
      instructions: err.instructions || browserManager.getLaunchInstructions(),
    });
  }
});

// ---------------------------------------------------------------------
// Start scraping (fire-and-forget; progress comes via /events SSE stream)
// ---------------------------------------------------------------------
router.post('/scrape/start', async (req, res) => {
  if (state.status === 'scraping') {
    return res.status(409).json({ ok: false, error: 'A scrape is already in progress.' });
  }

  try {
    await browserManager.findGoogleMapsPage();
  } catch (err) {
    return res.status(400).json({ ok: false, error: err.message });
  }

  res.json({ ok: true, message: 'Scrape started.' });

  scraper.runScrape().catch((err) => {
    state.status = 'error';
    state.state({ status: 'error' });
    logger.error(`Scrape failed: ${err.message}`);
  });
});

router.post('/scrape/cancel', (req, res) => {
  scraper.cancelScrape();
  res.json({ ok: true, message: 'Cancellation requested.' });
});

// ---------------------------------------------------------------------
// Exports
// ---------------------------------------------------------------------
router.post('/export/excel', async (req, res) => {
  if (state.results.length === 0) {
    return res.status(400).json({ ok: false, error: 'No scraped data to export yet.' });
  }
  try {
    const { filename } = await exportManager.generateExcel();
    logger.success(`Exported Excel: ${filename}`);
    res.json({ ok: true, filename, downloadUrl: `/api/download/${encodeURIComponent(filename)}` });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

router.post('/export/csv', (req, res) => {
  if (state.results.length === 0) {
    return res.status(400).json({ ok: false, error: 'No scraped data to export yet.' });
  }
  try {
    const { filename } = exportManager.generateCsv();
    logger.success(`Exported CSV: ${filename}`);
    res.json({ ok: true, filename, downloadUrl: `/api/download/${encodeURIComponent(filename)}` });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

router.get('/download/:filename', (req, res) => {
  const config = require('../../config/config');
  const filePath = path.join(config.paths.exportsDir, req.params.filename);
  if (!filePath.startsWith(config.paths.exportsDir)) {
    return res.status(400).send('Invalid filename.');
  }
  res.download(filePath);
});

module.exports = router;
