const fs = require('fs');
const path = require('path');
const config = require('../../config/config');

/**
 * Holds the in-memory state of the current scrape job and persists it to
 * disk after every business so a crash/restart can resume from where it
 * left off.
 */
class ScrapeState {
  constructor() {
    this.reset();
  }

  reset() {
    this.status = 'idle'; // idle | connecting | connected | scraping | cancelled | done | error
    this.chromeConnected = false;
    this.googleMapsDetected = false;
    this.searchQuery = null;
    this.businesses = [];        // discovered { name, mapsUrl } stubs from the list
    this.results = [];           // fully scraped records
    this.currentBusinessName = null;
    this.totalFound = 0;
    this.totalScraped = 0;
    this.startedAt = null;
    this.avgMsPerBusiness = null;
    this.cancelRequested = false;
  }

  ensureDataDir() {
    if (!fs.existsSync(config.paths.dataDir)) {
      fs.mkdirSync(config.paths.dataDir, { recursive: true });
    }
    if (!fs.existsSync(config.paths.exportsDir)) {
      fs.mkdirSync(config.paths.exportsDir, { recursive: true });
    }
  }

  persist() {
    this.ensureDataDir();
    const snapshot = {
      searchQuery: this.searchQuery,
      businesses: this.businesses,
      results: this.results,
      totalFound: this.totalFound,
      totalScraped: this.totalScraped,
      savedAt: new Date().toISOString(),
    };
    fs.writeFileSync(config.paths.progressFile, JSON.stringify(snapshot, null, 2));
  }

  loadPersisted() {
    if (fs.existsSync(config.paths.progressFile)) {
      try {
        const raw = fs.readFileSync(config.paths.progressFile, 'utf-8');
        return JSON.parse(raw);
      } catch (e) {
        return null;
      }
    }
    return null;
  }

  clearPersisted() {
    if (fs.existsSync(config.paths.progressFile)) {
      fs.unlinkSync(config.paths.progressFile);
    }
  }

  publicSnapshot() {
    const elapsedMs = this.startedAt ? Date.now() - this.startedAt : 0;
    let etaSeconds = null;
    if (this.avgMsPerBusiness && this.totalFound > this.totalScraped) {
      const remaining = this.totalFound - this.totalScraped;
      etaSeconds = Math.round((remaining * this.avgMsPerBusiness) / 1000);
    }
    return {
      status: this.status,
      chromeConnected: this.chromeConnected,
      googleMapsDetected: this.googleMapsDetected,
      searchQuery: this.searchQuery,
      totalFound: this.totalFound,
      totalScraped: this.totalScraped,
      currentBusinessName: this.currentBusinessName,
      elapsedMs,
      etaSeconds,
      resultCount: this.results.length,
    };
  }
}

module.exports = new ScrapeState();
