const { chromium } = require('playwright');
const os = require('os');
const config = require('../../config/config');
const logger = require('./logger');
const state = require('../state/scrapeState');

let browser = null;
let mapsPage = null;

/**
 * Returns OS-specific instructions for launching Chrome with remote
 * debugging enabled. Shown in the UI when a connection attempt fails.
 */
function getLaunchInstructions() {
  const platform = os.platform();
  const port = new URL(config.chrome.cdpUrl).port || '9222';

  const common = `Close ALL running Chrome windows first, then launch Chrome with remote debugging enabled on port ${port}.`;

  if (platform === 'win32') {
    return {
      platform: 'Windows',
      message: common,
      command: `chrome.exe --remote-debugging-port=${port}`,
      details: [
        'Press Win+R, paste the command below, and press Enter:',
        `"C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe" --remote-debugging-port=${port}`,
        'Or run it from an existing Command Prompt / PowerShell window.',
      ],
    };
  }
  if (platform === 'darwin') {
    return {
      platform: 'macOS',
      message: common,
      command: `open -a "Google Chrome" --args --remote-debugging-port=${port}`,
      details: [
        'Run this in Terminal:',
        `/Applications/Google\\ Chrome.app/Contents/MacOS/Google\\ Chrome --remote-debugging-port=${port}`,
      ],
    };
  }
  return {
    platform: 'Linux',
    message: common,
    command: `google-chrome --remote-debugging-port=${port}`,
    details: [
      'Run this in a terminal:',
      `google-chrome --remote-debugging-port=${port}`,
      'or "chromium-browser --remote-debugging-port=' + port + '" depending on your install.',
    ],
  };
}

/**
 * Connects to the already-running Chrome instance over CDP. Never launches
 * a new browser process of any kind.
 */
async function connect() {
  if (browser && browser.isConnected()) {
    return { alreadyConnected: true };
  }

  logger.log(`Attempting to connect to Chrome over CDP at ${config.chrome.cdpUrl} ...`);
  try {
    browser = await chromium.connectOverCDP(config.chrome.cdpUrl);
  } catch (err) {
    state.chromeConnected = false;
    state.status = 'error';
    logger.error(`Could not connect to Chrome on ${config.chrome.cdpUrl}. Is it running with --remote-debugging-port?`);
    const instructions = getLaunchInstructions();
    const error = new Error('CHROME_NOT_REACHABLE');
    error.instructions = instructions;
    throw error;
  }

  state.chromeConnected = true;
  state.status = 'connected';
  logger.success('Connected to Chrome.');
  state.state({ chromeConnected: true, status: 'connected' });
  return { alreadyConnected: false };
}

/**
 * Scans all open contexts/pages for one currently on a Google Maps search
 * or place URL. Returns the Playwright Page handle.
 */
async function findGoogleMapsPage() {
  if (!browser || !browser.isConnected()) {
    throw new Error('Not connected to Chrome. Call connect() first.');
  }

  const contexts = browser.contexts();
  for (const context of contexts) {
    for (const page of context.pages()) {
      const url = page.url();
      if (/^https:\/\/www\.google\.[a-z.]+\/maps/.test(url)) {
        mapsPage = page;
        state.googleMapsDetected = true;
        state.state({ googleMapsDetected: true });
        logger.success(`Google Maps tab detected: ${url}`);
        return mapsPage;
      }
    }
  }

  state.googleMapsDetected = false;
  state.state({ googleMapsDetected: false });
  throw new Error('No open Google Maps tab was found. Open Google Maps and run a search in Chrome, then try again.');
}

function getBrowser() {
  return browser;
}

function getMapsPage() {
  return mapsPage;
}

async function disconnect() {
  if (browser) {
    try {
      // We only disconnect our CDP session; we never close the user's
      // actual Chrome browser or tabs.
      await browser.close().catch(() => {});
    } catch (e) {
      // ignore
    }
  }
  browser = null;
  mapsPage = null;
  state.chromeConnected = false;
  state.googleMapsDetected = false;
}

module.exports = {
  connect,
  findGoogleMapsPage,
  getBrowser,
  getMapsPage,
  disconnect,
  getLaunchInstructions,
};
