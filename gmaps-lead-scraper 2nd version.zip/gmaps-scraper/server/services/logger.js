const { EventEmitter } = require('events');

/**
 * Central event bus. Server-Sent Events (SSE) clients subscribe to this
 * to receive live log lines and progress/state updates without needing
 * websockets or any extra dependency.
 */
class Logger extends EventEmitter {
  log(message, level = 'info') {
    const entry = {
      type: 'log',
      level,
      message,
      timestamp: new Date().toISOString(),
    };
    console.log(`[${entry.timestamp}] ${message}`);
    this.emit('event', entry);
  }

  error(message) {
    this.log(message, 'error');
  }

  warn(message) {
    this.log(message, 'warn');
  }

  success(message) {
    this.log(message, 'success');
  }

  state(statePatch) {
    const entry = {
      type: 'state',
      state: statePatch,
      timestamp: new Date().toISOString(),
    };
    this.emit('event', entry);
  }
}

module.exports = new Logger();
