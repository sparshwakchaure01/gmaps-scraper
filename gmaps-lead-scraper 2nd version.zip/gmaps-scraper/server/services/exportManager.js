const ExcelJS = require('exceljs');
const fs = require('fs');
const path = require('path');
const config = require('../../config/config');
const state = require('../state/scrapeState');

const COLUMNS = [
  { header: 'Business Name', key: 'name', width: 28 },
  { header: 'Category', key: 'category', width: 20 },
  { header: 'Phone', key: 'phone', width: 16 },
  { header: 'Rating', key: 'rating', width: 10 },
  { header: 'Reviews', key: 'reviewCount', width: 10 },
  { header: 'Address', key: 'address', width: 36 },
  { header: 'Website', key: 'website', width: 30 },
  { header: 'Website Type', key: 'websiteType', width: 14 },
  { header: 'Website Quality', key: 'websiteQuality', width: 14 },
  { header: 'Google Maps Link', key: 'mapsUrl', width: 40 },
  { header: 'Latitude', key: 'lat', width: 12 },
  { header: 'Longitude', key: 'lng', width: 12 },
  { header: 'Opening Hours', key: 'openingHours', width: 24 },
  { header: 'Priority', key: 'priority', width: 12 },
  { header: 'Contacted', key: 'contacted', width: 12 },
  { header: 'Follow-up Date', key: 'followUpDate', width: 14 },
  { header: 'Deal Status', key: 'dealStatus', width: 14 },
  { header: 'Notes', key: 'notes', width: 30 },
];

const PRIORITY_FILL = {
  'Very High': 'FFB30000',
  High: 'FFE67E22',
  Medium: 'FFF1C40F',
  Low: 'FF2ECC71',
};

function safeFilenameBase() {
  const query = (state.searchQuery || 'gmaps_leads').trim().replace(/[^a-z0-9]+/gi, '_');
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  return `${query}_${stamp}`;
}

async function generateExcel() {
  state.ensureDataDir();
  const workbook = new ExcelJS.Workbook();
  workbook.creator = 'Google Maps Lead Scraper';
  workbook.created = new Date();

  const sheet = workbook.addWorksheet('Leads', {
    views: [{ state: 'frozen', ySplit: 1 }],
  });

  sheet.columns = COLUMNS;

  const headerRow = sheet.getRow(1);
  headerRow.font = { bold: true, color: { argb: 'FFFFFFFF' } };
  headerRow.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1A73E8' } };
  headerRow.alignment = { vertical: 'middle', horizontal: 'center' };
  headerRow.height = 20;

  state.results.forEach((record, index) => {
    const row = sheet.addRow(record);
    const isEven = index % 2 === 0;
    row.eachCell((cell) => {
      cell.fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: isEven ? 'FFF3F6FB' : 'FFFFFFFF' },
      };
      cell.alignment = { vertical: 'middle' };
      cell.border = {
        bottom: { style: 'thin', color: { argb: 'FFE0E0E0' } },
      };
    });

    const priorityCell = row.getCell('priority');
    const fillColor = PRIORITY_FILL[record.priority];
    if (fillColor) {
      priorityCell.font = { bold: true, color: { argb: 'FFFFFFFF' } };
      priorityCell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: fillColor } };
      priorityCell.alignment = { vertical: 'middle', horizontal: 'center' };
    }

    if (record.mapsUrl) {
      const mapsCell = row.getCell('mapsUrl');
      mapsCell.value = { text: record.mapsUrl, hyperlink: record.mapsUrl };
      mapsCell.font = { color: { argb: 'FF1A73E8' }, underline: true };
    }
    if (record.website) {
      const websiteCell = row.getCell('website');
      websiteCell.value = { text: record.website, hyperlink: record.website };
      websiteCell.font = { color: { argb: 'FF1A73E8' }, underline: true };
    }
  });

  // Auto-size columns based on content length (in addition to the base widths above)
  sheet.columns.forEach((column) => {
    let maxLength = column.header ? column.header.length : 10;
    column.eachCell({ includeEmpty: false }, (cell) => {
      const value = cell.value && cell.value.text ? cell.value.text : cell.value;
      const length = value ? String(value).length : 0;
      if (length > maxLength) maxLength = length;
    });
    column.width = Math.min(Math.max(maxLength + 2, column.width || 10), 60);
  });

  sheet.autoFilter = { from: 'A1', to: `${String.fromCharCode(64 + COLUMNS.length)}1` };

  const filename = `${safeFilenameBase()}.xlsx`;
  const filePath = path.join(config.paths.exportsDir, filename);
  await workbook.xlsx.writeFile(filePath);
  return { filePath, filename };
}

function csvEscape(value) {
  if (value === null || value === undefined) return '';
  const str = String(value);
  if (/[",\n]/.test(str)) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
}

function generateCsv() {
  state.ensureDataDir();
  const header = COLUMNS.map((c) => c.header).join(',');
  const lines = state.results.map((record) =>
    COLUMNS.map((c) => csvEscape(record[c.key])).join(',')
  );
  const content = [header, ...lines].join('\r\n');

  const filename = `${safeFilenameBase()}.csv`;
  const filePath = path.join(config.paths.exportsDir, filename);
  fs.writeFileSync(filePath, content, 'utf-8');
  return { filePath, filename };
}

module.exports = { generateExcel, generateCsv };
