const config = require('../../config/config');
const logger = require('./logger');

/**
 * Classifies a business website URL by opening it in an isolated browser
 * context (separate from the Maps tab) and inspecting the final URL and
 * response status.
 *
 * Returns { websiteType, websiteQuality }
 *   websiteType: Website | Instagram | Facebook | WhatsApp | None
 *   websiteQuality: Working | Broken
 */
async function analyzeWebsite(browser, url) {
  if (!url) {
    return { websiteType: 'None', websiteQuality: 'Broken' };
  }

  const lower = url.toLowerCase();
  if (lower.includes('instagram.com')) {
    return { websiteType: 'Instagram', websiteQuality: await quickReachabilityCheck(browser, url) };
  }
  if (lower.includes('facebook.com') || lower.includes('fb.com')) {
    return { websiteType: 'Facebook', websiteQuality: await quickReachabilityCheck(browser, url) };
  }
  if (lower.includes('wa.me') || lower.includes('api.whatsapp.com') || lower.includes('whatsapp.com')) {
    return { websiteType: 'WhatsApp', websiteQuality: await quickReachabilityCheck(browser, url) };
  }

  // Generic website — open it in an isolated context to determine health.
  let context;
  try {
    context = await browser.newContext();
    const page = await context.newPage();
    let status = null;

    page.on('response', (response) => {
      if (response.url() === url || status === null) {
        status = response.status();
      }
    });

    const response = await page.goto(url, {
      timeout: config.scraper.websiteTimeoutMs,
      waitUntil: 'domcontentloaded',
    });

    const finalUrl = page.url().toLowerCase();
    await context.close();

    if (finalUrl.includes('instagram.com')) return { websiteType: 'Instagram', websiteQuality: 'Working' };
    if (finalUrl.includes('facebook.com')) return { websiteType: 'Facebook', websiteQuality: 'Working' };
    if (finalUrl.includes('whatsapp.com') || finalUrl.includes('wa.me')) return { websiteType: 'WhatsApp', websiteQuality: 'Working' };

    const httpStatus = response ? response.status() : null;
    if (!httpStatus || httpStatus >= 400) {
      return { websiteType: 'Website', websiteQuality: 'Broken' };
    }
    return { websiteType: 'Website', websiteQuality: 'Working' };
  } catch (err) {
    if (context) await context.close().catch(() => {});
    logger.warn(`Website check timed out or failed for ${url}: ${err.message}`);
    return { websiteType: 'Website', websiteQuality: 'Broken' };
  }
}

async function quickReachabilityCheck(browser, url) {
  let context;
  try {
    context = await browser.newContext();
    const page = await context.newPage();
    const response = await page.goto(url, {
      timeout: config.scraper.websiteTimeoutMs,
      waitUntil: 'domcontentloaded',
    });
    await context.close();
    const status = response ? response.status() : null;
    return !status || status >= 400 ? 'Broken' : 'Working';
  } catch (e) {
    if (context) await context.close().catch(() => {});
    return 'Broken';
  }
}

module.exports = { analyzeWebsite };
