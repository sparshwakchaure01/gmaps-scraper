const config = require('../../config/config');
const logger = require('./logger');
const state = require('../state/scrapeState');
const locatorManager = require('./locatorManager');
const websiteAnalyzer = require('./websiteAnalyzer');
const { calculatePriority } = require('./priority');
const browserManager = require('./browserManager');

/**
 * NOTE ON NAVIGATION STRATEGY
 * ---------------------------
 * Rather than repeatedly clicking a list item and clicking "Back" (which is
 * fragile because Google Maps re-renders the results feed DOM after every
 * navigation), this scraper first collects the direct place URL for every
 * business while scrolling the feed, then visits each place URL directly
 * with page.goto(). This is functionally identical from the user's point of
 * view (each business opens fully, is scraped, and the app moves on to the
 * next one) but is far less prone to breaking when Maps changes list
 * markup mid-session. When all businesses are processed we navigate back to
 * the original search results URL so the user's tab ends up where they left
 * off.
 */

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function scrollAndCollectBusinesses(page) {
  logger.log('Loading businesses... scrolling results panel.');
  const feed = await locatorManager.resolve(page, 'resultsFeed', { timeout: config.scraper.navigationTimeoutMs });

  const seen = new Map(); // href -> name
  let stagnantRounds = 0;

  while (stagnantRounds < config.scraper.maxStagnantScrolls && !state.cancelRequested) {
    const anchors = await page.locator('div[role="feed"] a[href*="/maps/place/"]').all();

    for (const anchor of anchors) {
      try {
        const href = await anchor.getAttribute('href');
        if (!href || seen.has(href)) continue;
        const name = (await anchor.getAttribute('aria-label')) || (await anchor.innerText().catch(() => null)) || 'Unknown';
        seen.set(href, name.trim());
      } catch (e) {
        continue; // never crash on a single bad anchor
      }
    }

    const beforeCount = seen.size;
    await feed.first().hover().catch(() => {});
    await page.mouse.wheel(0, 1800);
    await sleep(config.scraper.scrollDelayMs);
    const afterCount = seen.size;

    if (afterCount === beforeCount) {
      stagnantRounds += 1;
    } else {
      stagnantRounds = 0;
      state.totalFound = seen.size;
      state.state({ totalFound: seen.size });
      logger.log(`Businesses found so far: ${seen.size}`);
    }
  }

  const businesses = Array.from(seen.entries()).map(([href, name]) => ({ href, name }));
  logger.success(`Finished scrolling. Total businesses found: ${businesses.length}`);
  return businesses;
}

async function extractBusinessDetails(page, stub) {
  await locatorManager.resolve(page, 'businessNameHeading', { timeout: config.scraper.navigationTimeoutMs, requireVisible: true });
  await sleep(config.scraper.businessLoadDelayMs);

  const name = (await locatorManager.safeText(page, 'businessNameHeading')) || stub.name || null;
  const category = await locatorManager.safeText(page, 'businessCategory');
  const phone = await extractPhone(page);
  const address = await extractAddress(page);
  const website = await locatorManager.safeAttribute(page, 'websiteLink', 'href');
  const { rating, reviewCount } = await extractRatingAndReviews(page);
  const openingHours = await locatorManager.safeText(page, 'openingHours');
  const businessStatus = await locatorManager.safeText(page, 'businessStatus');
  const { lat, lng } = extractLatLngFromUrl(page.url());

  return {
    name,
    category,
    phone,
    address,
    website,
    rating,
    reviewCount,
    openingHours,
    businessStatus,
    mapsUrl: page.url(),
    lat,
    lng,
  };
}

async function extractPhone(page) {
  const text = await locatorManager.safeText(page, 'phoneButton');
  if (!text) return null;
  return text.replace(/^Phone:\s*/i, '').trim();
}

async function extractAddress(page) {
  const label = await locatorManager.safeAttribute(page, 'addressButton', 'aria-label');
  if (label) return label.replace(/^Address:\s*/i, '').trim();
  return locatorManager.safeText(page, 'addressButton');
}

async function extractRatingAndReviews(page) {
  let rating = null;
  let reviewCount = null;
  try {
    const ratingLocator = await locatorManager.resolve(page, 'ratingValue', { timeout: 2000 });
    const ariaLabel = await ratingLocator.first().getAttribute('aria-label').catch(() => null);
    if (ariaLabel) {
      const match = ariaLabel.match(/([\d.]+)\s*stars?/i);
      if (match) rating = match[1];
    }
  } catch (e) {
    // leave blank, never crash
  }

  try {
    const reviewLocator = await locatorManager.resolve(page, 'reviewCount', { timeout: 2000 });
    const text = await reviewLocator.first().innerText().catch(() => null);
    if (text) {
      const match = text.match(/([\d,]+)/);
      if (match) reviewCount = match[1].replace(/,/g, '');
    }
  } catch (e) {
    // leave blank
  }

  return { rating, reviewCount };
}

function extractLatLngFromUrl(url) {
  const match = url.match(/@(-?\d+\.\d+),(-?\d+\.\d+)/);
  if (match) {
    return { lat: match[1], lng: match[2] };
  }
  return { lat: null, lng: null };
}

/**
 * Main entry point. Runs the full scrape workflow against the already
 * detected Google Maps search page.
 */
async function runScrape() {
  const page = browserManager.getMapsPage();
  if (!page) {
    throw new Error('No Google Maps page connected.');
  }

  state.status = 'scraping';
  state.cancelRequested = false;
  state.startedAt = Date.now();
  const searchUrl = page.url();
  state.searchQuery = decodeURIComponent((searchUrl.match(/\/maps\/search\/([^/]+)/) || [])[1] || '').replace(/\+/g, ' ');
  state.state({ status: 'scraping', searchQuery: state.searchQuery });

  const businesses = await scrollAndCollectBusinesses(page);
  state.businesses = businesses;
  state.totalFound = businesses.length;
  state.state({ totalFound: businesses.length });

  const browser = browserManager.getBrowser();
  const durations = [];

  for (let i = 0; i < businesses.length; i++) {
    if (state.cancelRequested) {
      logger.warn('Scrape cancelled by user.');
      state.status = 'cancelled';
      state.state({ status: 'cancelled' });
      break;
    }

    const stub = businesses[i];
    state.currentBusinessName = stub.name;
    state.state({ currentBusinessName: stub.name });
    logger.log(`Business ${i + 1} of ${businesses.length}`);
    logger.log(`Scraping ${stub.name}...`);

    const businessStart = Date.now();
    let record = null;
    let attempt = 0;
    let lastError = null;

    while (attempt <= config.scraper.maxRetries && !record) {
      try {
        await page.goto(stub.href, { timeout: config.scraper.navigationTimeoutMs, waitUntil: 'domcontentloaded' });
        record = await extractBusinessDetails(page, stub);
      } catch (err) {
        lastError = err;
        attempt += 1;
        if (attempt <= config.scraper.maxRetries) {
          logger.warn(`Retrying ${stub.name} (attempt ${attempt + 1})...`);
          await sleep(1000);
        }
      }
    }

    if (!record) {
      logger.error(`Skipping ${stub.name} after failed retries: ${lastError ? lastError.message : 'unknown error'}`);
      record = {
        name: stub.name,
        category: null,
        phone: null,
        address: null,
        website: null,
        rating: null,
        reviewCount: null,
        openingHours: null,
        businessStatus: null,
        mapsUrl: stub.href,
        lat: null,
        lng: null,
      };
    }

    // Website analysis (best-effort, never blocks the main loop from continuing)
    let websiteType = 'None';
    let websiteQuality = 'Broken';
    if (record.website) {
      try {
        const analysis = await websiteAnalyzer.analyzeWebsite(browser, record.website);
        websiteType = analysis.websiteType;
        websiteQuality = analysis.websiteQuality;
      } catch (e) {
        logger.warn(`Website analysis failed for ${stub.name}: ${e.message}`);
      }
    }

    const priority = calculatePriority({
      websiteType,
      websiteQuality,
      rating: record.rating,
      reviewCount: record.reviewCount,
    });

    const fullRecord = {
      ...record,
      websiteType,
      websiteQuality,
      priority,
      contacted: '',
      followUpDate: '',
      dealStatus: '',
      notes: '',
    };

    state.results.push(fullRecord);
    state.totalScraped = state.results.length;
    durations.push(Date.now() - businessStart);
    state.avgMsPerBusiness = durations.reduce((a, b) => a + b, 0) / durations.length;
    state.persist();
    state.state({ totalScraped: state.totalScraped });
    logger.success(`Saved (${state.totalScraped}/${businesses.length})`);
  }

  if (!state.cancelRequested) {
    state.status = 'done';
    state.state({ status: 'done' });
    logger.success('Finished scraping all businesses.');
  }

  // Return the user's tab to the original search results.
  try {
    await page.goto(searchUrl, { waitUntil: 'domcontentloaded', timeout: config.scraper.navigationTimeoutMs });
  } catch (e) {
    logger.warn('Could not navigate back to the original search results page.');
  }

  return state.results;
}

function cancelScrape() {
  state.cancelRequested = true;
}

module.exports = { runScrape, cancelScrape };
