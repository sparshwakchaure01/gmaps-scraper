/**
 * Assigns a lead priority label based on website presence/type/quality and
 * rating/review signals, per the following rules:
 *
 *  Very High: no website AND rating > 4.2 AND reviews > 100
 *  High:      website is Instagram-only / Facebook-only / WhatsApp-only, OR website is Broken
 *  Medium:    working generic website
 *  Low:       "modern" website (treated as a healthy, working website with strong signals)
 */
function calculatePriority({ websiteType, websiteQuality, rating, reviewCount }) {
  const numericRating = parseFloat(rating) || 0;
  const numericReviews = parseInt(reviewCount, 10) || 0;

  if (websiteType === 'None' && numericRating > 4.2 && numericReviews > 100) {
    return 'Very High';
  }

  if (['Instagram', 'Facebook', 'WhatsApp'].includes(websiteType)) {
    return 'High';
  }

  if (websiteType === 'Website' && websiteQuality === 'Broken') {
    return 'High';
  }

  if (websiteType === 'Website' && websiteQuality === 'Working') {
    // Strong existing web presence with good ratings reads as a lower-urgency / "modern" lead.
    if (numericRating >= 4.0 && numericReviews >= 50) {
      return 'Low';
    }
    return 'Medium';
  }

  return 'Medium';
}

module.exports = { calculatePriority };
