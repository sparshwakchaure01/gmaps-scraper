/**
 * LOCATOR MANAGER
 * ----------------
 * Single source of truth for every element the scraper needs to find on
 * Google Maps. Each entry is an ordered array of "strategy" functions that
 * take a Playwright scope (Page or Locator) and return a Locator.
 *
 * Strategies are tried in priority order:
 *   1. getByRole()
 *   2. getByLabel()
 *   3. getByPlaceholder()
 *   4. ARIA attribute selectors
 *   5. Visible text
 *   6. Stable ID-ish attributes
 *   7. CSS selector (last resort fallback only)
 *
 * If a strategy's locator doesn't resolve to a visible element within the
 * timeout, the next strategy is attempted automatically. The name of the
 * strategy that succeeded is logged so failures are easy to diagnose and
 * repair in this one file.
 */

const logger = require('./logger');

const LOCATORS = {
  // The scrollable left-hand results list on a Maps search page
  resultsFeed: [
    { name: 'role=feed', fn: (s) => s.getByRole('feed') },
    { name: 'aria role=feed css', fn: (s) => s.locator('div[role="feed"]') },
    { name: 'results panel css fallback', fn: (s) => s.locator('div.m6QErb[role="feed"]') },
  ],

  // Each clickable business card/row inside the results feed
  businessResultItem: [
    { name: 'feed link role', fn: (s) => s.getByRole('link').filter({ hasNotText: '' }) },
    { name: 'aria-label article css', fn: (s) => s.locator('div[role="feed"] > div > div[jsaction] a[href*="/maps/place/"]') },
    { name: 'anchor href place fallback', fn: (s) => s.locator('a[href*="/maps/place/"]') },
  ],

  // Business name heading on the details panel
  businessNameHeading: [
    { name: 'role=heading level 1', fn: (s) => s.getByRole('heading', { level: 1 }) },
    { name: 'h1 css fallback', fn: (s) => s.locator('h1').first() },
  ],

  // Category (e.g. "Cafe")
  businessCategory: [
    { name: 'button category role', fn: (s) => s.getByRole('button', { name: /.+/ }).locator('xpath=ancestor::*[self::div][1]//button[contains(@jsaction,"category")]') },
    { name: 'category css fallback', fn: (s) => s.locator('button[jsaction*="category"]').first() },
  ],

  // Phone number button
  phoneButton: [
    { name: 'aria-label starts-with Phone', fn: (s) => s.locator('button[aria-label^="Phone:"]') },
    { name: 'data-item-id phone css', fn: (s) => s.locator('button[data-item-id^="phone:"]') },
    { name: 'visible text tel pattern', fn: (s) => s.getByText(/^\+?\d[\d\s().-]{6,}$/).first() },
  ],

  // Address button
  addressButton: [
    { name: 'aria-label starts-with Address', fn: (s) => s.locator('button[aria-label^="Address:"]') },
    { name: 'data-item-id address css', fn: (s) => s.locator('button[data-item-id="address"]') },
  ],

  // Website link
  websiteLink: [
    { name: 'aria-label starts-with Website', fn: (s) => s.locator('a[aria-label^="Website:"]') },
    { name: 'data-item-id authority css', fn: (s) => s.locator('a[data-item-id="authority"]') },
  ],

  // Rating value (near the star icon)
  ratingValue: [
    { name: 'aria-label rating role img', fn: (s) => s.getByRole('img', { name: /stars?/i }) },
    { name: 'rating span css fallback', fn: (s) => s.locator('div.F7nice span[aria-hidden="true"]').first() },
  ],

  // Review count text, e.g. "(1,234)"
  reviewCount: [
    { name: 'role button reviews name', fn: (s) => s.getByRole('button', { name: /reviews?/i }) },
    { name: 'reviews span css fallback', fn: (s) => s.locator('div.F7nice span[aria-label*="review"]').first() },
  ],

  // Opening hours expandable row
  openingHours: [
    { name: 'aria-label Hours button', fn: (s) => s.locator('button[aria-label^="Hours"]') },
    { name: 'hours text row css fallback', fn: (s) => s.locator('div[jsaction*="openhours"]').first() },
  ],

  // Business status label ("Open", "Closed", "Permanently closed")
  businessStatus: [
    { name: 'status span visible text', fn: (s) => s.getByText(/Open now|Closed|Permanently closed|Temporarily closed/i).first() },
  ],

  // Back button on the business details panel
  backButton: [
    { name: 'role=button name Back', fn: (s) => s.getByRole('button', { name: 'Back' }) },
    { name: 'aria-label Back css fallback', fn: (s) => s.locator('button[aria-label="Back"]') },
  ],

  // Search box (used only to detect that this is a Maps search page - never typed into)
  searchBox: [
    { name: 'role=combobox name Search', fn: (s) => s.getByRole('combobox', { name: /search/i }) },
    { name: 'search input id fallback', fn: (s) => s.locator('#searchboxinput') },
  ],
};

const DEFAULT_TIMEOUT_MS = 3000;

/**
 * Attempts each strategy for `key` in order against `scope`.
 * Returns the first Locator that resolves to at least one attached element.
 * Throws if every strategy fails.
 */
async function resolve(scope, key, { timeout = DEFAULT_TIMEOUT_MS, requireVisible = false } = {}) {
  const strategies = LOCATORS[key];
  if (!strategies) {
    throw new Error(`LocatorManager: unknown locator key "${key}"`);
  }

  let lastError = null;
  for (const strategy of strategies) {
    try {
      const locator = strategy.fn(scope);
      const target = locator.first();
      if (requireVisible) {
        await target.waitFor({ state: 'visible', timeout });
      } else {
        await target.waitFor({ state: 'attached', timeout });
      }
      logger.log(`Locator OK: "${key}" resolved via strategy "${strategy.name}"`);
      return locator;
    } catch (err) {
      lastError = err;
      continue;
    }
  }
  throw new Error(`LocatorManager: all strategies failed for "${key}" (${lastError ? lastError.message : 'no error detail'})`);
}

/**
 * Best-effort text extraction: resolves the locator and returns trimmed
 * innerText, or null if nothing could be resolved / extracted.
 */
async function safeText(scope, key, opts = {}) {
  try {
    const locator = await resolve(scope, key, opts);
    const text = (await locator.first().innerText({ timeout: 2000 })).trim();
    return text || null;
  } catch (e) {
    return null;
  }
}

/**
 * Best-effort attribute extraction.
 */
async function safeAttribute(scope, key, attribute, opts = {}) {
  try {
    const locator = await resolve(scope, key, opts);
    const value = await locator.first().getAttribute(attribute, { timeout: 2000 });
    return value ? value.trim() : null;
  } catch (e) {
    return null;
  }
}

module.exports = { LOCATORS, resolve, safeText, safeAttribute };
