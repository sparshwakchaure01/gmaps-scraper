const express = require('express');
const path = require('path');
const config = require('../config/config');
const apiRoutes = require('./routes/api');
const state = require('./state/scrapeState');
const logger = require('./services/logger');

const app = express();

app.use(express.json());
app.use('/api', apiRoutes);
app.use(express.static(path.join(__dirname, '..', 'public')));

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
});

// Resume support: if a previous run left progress on disk, load it into
// state on startup so the user can pick up where they left off (re-export,
// or see the last count) even after a crash/restart.
const persisted = state.loadPersisted();
if (persisted && persisted.results && persisted.results.length > 0) {
  state.results = persisted.results;
  state.businesses = persisted.businesses || [];
  state.totalFound = persisted.totalFound || 0;
  state.totalScraped = persisted.totalScraped || 0;
  state.searchQuery = persisted.searchQuery || null;
  console.log(`Resumed previous session: ${state.results.length} businesses already scraped.`);
}

app.listen(config.server.port, () => {
  console.log(`Google Maps Lead Scraper running at http://localhost:${config.server.port}`);
  console.log('Open that URL in a browser (this can be a different Chrome window/profile than the one you use for Google Maps).');
});
