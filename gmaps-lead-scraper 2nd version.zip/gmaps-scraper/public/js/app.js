(function () {
  const el = {
    dotChrome: document.getElementById('dot-chrome'),
    valChrome: document.getElementById('val-chrome'),
    dotMaps: document.getElementById('dot-maps'),
    valMaps: document.getElementById('val-maps'),
    valFound: document.getElementById('val-found'),
    valScraped: document.getElementById('val-scraped'),
    currentBusiness: document.getElementById('current-business'),
    eta: document.getElementById('eta'),
    progressFill: document.getElementById('progress-fill'),
    btnConnect: document.getElementById('btn-connect'),
    btnScrape: document.getElementById('btn-scrape'),
    btnCancel: document.getElementById('btn-cancel'),
    btnExportExcel: document.getElementById('btn-export-excel'),
    btnExportCsv: document.getElementById('btn-export-csv'),
    instructions: document.getElementById('instructions'),
    logWindow: document.getElementById('log-window'),
  };

  let latestState = {
    status: 'idle',
    chromeConnected: false,
    googleMapsDetected: false,
    totalFound: 0,
    totalScraped: 0,
  };

  function appendLog(message, level) {
    const line = document.createElement('div');
    line.className = `log-line ${level || ''}`.trim();
    line.textContent = message;
    el.logWindow.appendChild(line);
    el.logWindow.scrollTop = el.logWindow.scrollHeight;
  }

  function formatEta(seconds) {
    if (seconds === null || seconds === undefined) return '--';
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m}m ${s}s remaining`;
  }

  function render() {
    el.dotChrome.classList.toggle('connected', !!latestState.chromeConnected);
    el.valChrome.textContent = latestState.chromeConnected ? 'Connected' : 'Not connected';

    el.dotMaps.classList.toggle('connected', !!latestState.googleMapsDetected);
    el.valMaps.textContent = latestState.googleMapsDetected ? 'Detected' : 'Not detected';

    el.valFound.textContent = latestState.totalFound || 0;
    el.valScraped.textContent = latestState.totalScraped || 0;

    const pct = latestState.totalFound > 0
      ? Math.round((latestState.totalScraped / latestState.totalFound) * 100)
      : 0;
    el.progressFill.style.width = `${pct}%`;

    el.currentBusiness.textContent = latestState.status === 'scraping'
      ? `Scraping: ${latestState.currentBusinessName || '...'}`
      : (latestState.status === 'done' ? 'Finished' : (latestState.status === 'cancelled' ? 'Cancelled' : 'Idle'));

    el.eta.textContent = latestState.status === 'scraping' ? formatEta(latestState.etaSeconds) : '--';

    el.btnConnect.disabled = latestState.chromeConnected && latestState.googleMapsDetected;
    el.btnScrape.disabled = !latestState.googleMapsDetected || latestState.status === 'scraping';
    el.btnCancel.disabled = latestState.status !== 'scraping';
    const hasResults = (latestState.resultCount || 0) > 0;
    el.btnExportExcel.disabled = !hasResults;
    el.btnExportCsv.disabled = !hasResults;
  }

  function connectSSE() {
    const source = new EventSource('/api/events');
    source.onmessage = (event) => {
      const data = JSON.parse(event.data);
      if (data.type === 'log') {
        appendLog(data.message, data.level);
      } else if (data.type === 'state') {
        latestState = { ...latestState, ...data.state };
        render();
      }
    };
    source.onerror = () => {
      // Browser auto-reconnects EventSource; nothing to do here.
    };
  }

  function showInstructions(instructions) {
    if (!instructions) {
      el.instructions.classList.add('hidden');
      return;
    }
    el.instructions.classList.remove('hidden');
    el.instructions.innerHTML = `
      <strong>Chrome isn't reachable on the debugging port (${instructions.platform}).</strong><br/>
      Close all Chrome windows, then launch it with remote debugging enabled:<br/>
      <code>${instructions.command}</code><br/>
      Then open Google Maps in that Chrome window, run your search, and click "Connect Chrome" again.
    `;
  }

  el.btnConnect.addEventListener('click', async () => {
    el.btnConnect.disabled = true;
    appendLog('Connecting to Chrome...');
    try {
      const res = await fetch('/api/connect', { method: 'POST' });
      const data = await res.json();
      if (!data.ok) {
        showInstructions(data.instructions);
        el.btnConnect.disabled = false;
        return;
      }
      showInstructions(null);
      latestState.chromeConnected = data.chromeConnected;
      latestState.googleMapsDetected = data.googleMapsDetected;
      if (!data.googleMapsDetected) {
        appendLog('Connected to Chrome, but no Google Maps search tab was found yet. Open Google Maps, search, then click Connect again.', 'warn');
      }
      render();
    } catch (err) {
      appendLog(`Connection error: ${err.message}`, 'error');
      el.btnConnect.disabled = false;
    }
  });

  el.btnScrape.addEventListener('click', async () => {
    el.btnScrape.disabled = true;
    try {
      const res = await fetch('/api/scrape/start', { method: 'POST' });
      const data = await res.json();
      if (!data.ok) {
        appendLog(data.error, 'error');
        el.btnScrape.disabled = false;
      }
    } catch (err) {
      appendLog(`Failed to start scrape: ${err.message}`, 'error');
      el.btnScrape.disabled = false;
    }
  });

  el.btnCancel.addEventListener('click', async () => {
    await fetch('/api/scrape/cancel', { method: 'POST' });
  });

  el.btnExportExcel.addEventListener('click', async () => {
    const res = await fetch('/api/export/excel', { method: 'POST' });
    const data = await res.json();
    if (data.ok) {
      window.location.href = data.downloadUrl;
    } else {
      appendLog(data.error, 'error');
    }
  });

  el.btnExportCsv.addEventListener('click', async () => {
    const res = await fetch('/api/export/csv', { method: 'POST' });
    const data = await res.json();
    if (data.ok) {
      window.location.href = data.downloadUrl;
    } else {
      appendLog(data.error, 'error');
    }
  });

  async function init() {
    const res = await fetch('/api/status');
    latestState = await res.json();
    render();
    connectSSE();
  }

  init();
})();
