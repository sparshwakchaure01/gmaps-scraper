# Google Maps Lead Scraper

A simple local tool: enter a search like "Cafe Sangamner", it opens each result on
Google Maps and saves Name, Phone, Website, Rating, Address, etc. into Excel.

## 1. Install Node.js (one-time)
Download and install from https://nodejs.org (choose the "LTS" version).
To check it worked, open a terminal / command prompt and type:
```
node -v
```
You should see something like `v20.x.x`.

## 2. Install the project
Open a terminal inside this folder (`gmaps-scraper`) and run:
```
npm install
```
This also downloads the Chromium browser Playwright needs (may take a minute).

## 3. Run it
```
npm start
```
You'll see: `Open http://localhost:3000 in your browser`.
Open that link in Chrome/Edge/Firefox.

## 4. Use it
1. Type a search keyword, e.g. `Footwear Shop Pune`.
2. Pick how many results (20/50/100/200).
3. Pick Excel or CSV.
4. Click **Start Scraping** and watch the log.
5. When done, click **Download**.

## Notes
- A Chromium browser window runs in the background (headless) — this is normal, it's how the tool "clicks around" Google Maps.
- Scraping 100 businesses takes a while (each one is visited individually, like a real user). Expect roughly 3-6 seconds per business.
- If Google changes their page layout, some fields may come back blank instead of crashing — the tool always keeps going and just leaves that field empty for that one business.
- This scrapes public business listing data. Doing this at scale isn't something Google's Terms of Service technically allow, so use it for your own research/lead-gen at reasonable volumes rather than running it constantly or reselling the data.
