const express = require('express');
const path = require('path');
const { runScrape } = require('./scraper');
const { saveExcel, saveCsv } = require('./exporter');

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const OUT_DIR = path.join(__dirname, 'output');
require('fs').mkdirSync(OUT_DIR, { recursive: true });

let state = {
  running: false,
  phase: 'idle',
  found: 0,
  current: 0,
  total: 0,
  scraped: 0,
  logs: [],
  fileReady: null,
};

function resetState() {
  state = { running: true, phase: 'starting', found: 0, current: 0, total: 0, scraped: 0, logs: [], fileReady: null };
}

app.post('/api/scrape', async (req, res) => {
  if (state.running) return res.status(409).json({ error: 'A scrape is already running.' });
  const { keyword, maxResults, format } = req.body;
  if (!keyword || !keyword.trim()) return res.status(400).json({ error: 'Keyword required.' });

  resetState();
  res.json({ started: true });

  try {
    const rows = await runScrape({
      keyword: keyword.trim(),
      maxResults: parseInt(maxResults) || 20,
      onProgress: (p) => { state = { ...state, ...p }; },
      onLog: (msg) => { state.logs.push(msg); if (state.logs.length > 200) state.logs.shift(); },
    });

    const stamp = Date.now();
    let fileName;
    if (format === 'csv') {
      fileName = `leads-${stamp}.csv`;
      saveCsv(rows, path.join(OUT_DIR, fileName));
    } else {
      fileName = `leads-${stamp}.xlsx`;
      await saveExcel(rows, path.join(OUT_DIR, fileName));
    }
    state.phase = 'done';
    state.fileReady = fileName;
    state.logs.push(`Done. ${rows.length} businesses saved to ${fileName}`);
  } catch (err) {
    state.phase = 'error';
    state.logs.push(`Fatal error: ${err.message}`);
  } finally {
    state.running = false;
  }
});

app.get('/api/status', (req, res) => res.json(state));

app.get('/api/download/:file', (req, res) => {
  const filePath = path.join(OUT_DIR, path.basename(req.params.file));
  res.download(filePath);
});

const PORT = 3000;
app.listen(PORT, () => console.log(`Open http://localhost:${PORT} in your browser`));
