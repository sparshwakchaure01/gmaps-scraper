const { chromium } = require('playwright');

function classifyWebsite(url) {
  if (!url) return 'None';
  if (url.includes('instagram.com')) return 'Instagram';
  if (url.includes('wa.me') || url.includes('api.whatsapp.com')) return 'WhatsApp';
  if (url.includes('facebook.com')) return 'Facebook';
  return 'Website';
}

function priorityFor(row) {
  const rating = parseFloat(row.rating) || 0;
  const reviews = parseInt(row.reviews) || 0;
  if (row.websiteType === 'None' && rating > 4.2 && reviews > 100) return 'Very High';
  if (['Instagram', 'WhatsApp', 'Facebook'].includes(row.websiteType) || row.websiteQuality === 'Broken') return 'High';
  if (row.websiteType === 'Website') return 'Medium';
  return 'Low';
}

async function safeText(locator) {
  try {
    const el = locator.first();
    if (await el.count() === 0) return '';
    return (await el.innerText({ timeout: 3000 })).trim();
  } catch {
    return '';
  }
}

async function safeAttr(locator, attr) {
  try {
    const el = locator.first();
    if (await el.count() === 0) return '';
    return (await el.getAttribute(attr, { timeout: 3000 })) || '';
  } catch {
    return '';
  }
}

async function scrapePlace(page, url) {
  await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 30000 });
  await page.waitForSelector('h1', { timeout: 15000 }).catch(() => {});
  await page.waitForTimeout(1200);

  const name = await safeText(page.locator('h1'));

  let category = '';
  try {
    category = await safeText(page.getByRole('button', { name: /^[A-Za-z].*$/ }).filter({ hasText: /.{2,40}/ }).nth(0));
  } catch {}
  // Fallback: category button usually sits right under the h1
  if (!category) {
    category = await safeText(page.locator('button[jsaction*="category"]'));
  }

  const phoneBtn = page.locator('button[data-item-id^="phone"]');
  let phone = await safeAttr(phoneBtn, 'aria-label');
  phone = phone.replace(/^Phone:\s*/i, '').trim();

  const addressBtn = page.locator('button[data-item-id="address"]');
  let address = await safeAttr(addressBtn, 'aria-label');
  address = address.replace(/^Address:\s*/i, '').trim();

  const websiteLink = page.locator('a[data-item-id="authority"]');
  const website = await safeAttr(websiteLink, 'href');

  let ratingText = await safeAttr(page.locator('span[role="img"][aria-label*="star"]'), 'aria-label');
  let rating = '';
  let reviews = '';
  const ratingMatch = ratingText.match(/([\d.]+)\s*star/i);
  if (ratingMatch) rating = ratingMatch[1];
  const reviewsText = await safeText(page.locator('button[aria-label*="review"]'));
  const reviewsMatch = reviewsText.match(/([\d,]+)/);
  if (reviewsMatch) reviews = reviewsMatch[1].replace(/,/g, '');

  let lat = '', lng = '';
  const finalUrl = page.url();
  const coordMatch = finalUrl.match(/@(-?\d+\.\d+),(-?\d+\.\d+)/);
  if (coordMatch) {
    lat = coordMatch[1];
    lng = coordMatch[2];
  }

  const bodyText = await safeText(page.locator('body'));
  let status = 'Open';
  if (/permanently closed/i.test(bodyText)) status = 'Permanently Closed';
  else if (/temporarily closed/i.test(bodyText)) status = 'Temporarily Closed';

  const websiteType = classifyWebsite(website);

  return {
    name, category, phone, address, rating, reviews,
    website: websiteType === 'None' ? '' : website,
    websiteType, googleMapsUrl: finalUrl, lat, lng, status
  };
}

async function checkWebsiteQuality(context, websiteType, url) {
  if (websiteType === 'None') return 'Broken';
  if (['Instagram', 'WhatsApp', 'Facebook'].includes(websiteType)) return 'Social Only';
  try {
    const page = await context.newPage();
    const resp = await page.goto(url, { timeout: 12000, waitUntil: 'domcontentloaded' });
    const ok = resp && resp.status() < 400;
    await page.close();
    return ok ? 'Working' : 'Broken';
  } catch {
    return 'Broken';
  }
}

async function runScrape({ keyword, maxResults, onProgress, onLog }) {
  const browser = await chromium.launch({ headless: true });
  const context = await browser.newContext();
  const page = await context.newPage();
  const results = [];
  const seenUrls = new Set();

  try {
    onLog(`Opening Google Maps...`);
    await page.goto('https://www.google.com/maps', { waitUntil: 'domcontentloaded', timeout: 30000 });

    const searchBox = page.getByRole('combobox', { name: /search google maps/i })
      .or(page.locator('input#searchboxinput'));
    await searchBox.first().fill(keyword);
    await searchBox.first().press('Enter');
    onLog(`Searching for "${keyword}"...`);

    const feed = page.locator('div[role="feed"]');
    await feed.waitFor({ timeout: 20000 }).catch(() => {});
    await page.waitForTimeout(2000);

    // Scroll to load results
    let stagnantRounds = 0;
    let links = [];
    while (links.length < maxResults && stagnantRounds < 4) {
      const anchors = await page.locator('a[href*="/maps/place/"]').evaluateAll(
        els => els.map(e => e.href)
      );
      const before = links.length;
      links = [...new Set(anchors)];
      if (links.length <= before) stagnantRounds++;
      else stagnantRounds = 0;

      onProgress({ phase: 'collecting', found: links.length });
      await feed.first().evaluate(el => el.scrollBy(0, 1200)).catch(() => {});
      await page.waitForTimeout(1500);
    }

    links = links.slice(0, maxResults);
    onLog(`Found ${links.length} businesses. Visiting each one...`);

    for (let i = 0; i < links.length; i++) {
      const url = links[i];
      if (seenUrls.has(url)) continue;
      seenUrls.add(url);

      onProgress({ phase: 'scraping', current: i + 1, total: links.length, currentUrl: url });

      let data = null;
      for (let attempt = 0; attempt < 2 && !data; attempt++) {
        try {
          data = await scrapePlace(page, url);
        } catch (err) {
          onLog(`Retrying business ${i + 1} (${err.message.slice(0, 60)})`);
        }
      }
      if (!data) {
        onLog(`Skipped business ${i + 1} after failed retry.`);
        continue;
      }

      onLog(`Checking website for: ${data.name || 'Unknown'}`);
      data.websiteQuality = await checkWebsiteQuality(context, data.websiteType, data.website);
      data.priority = priorityFor({ ...data, websiteQuality: data.websiteQuality });
      results.push(data);
      onProgress({ phase: 'scraping', current: i + 1, total: links.length, scraped: results.length });
    }
  } finally {
    await browser.close();
  }

  return results;
}

module.exports = { runScrape };
