const ExcelJS = require('exceljs');
const fs = require('fs');

const COLUMNS = [
  { header: 'Business Name', key: 'name', width: 28 },
  { header: 'Category', key: 'category', width: 18 },
  { header: 'Phone', key: 'phone', width: 16 },
  { header: 'Rating', key: 'rating', width: 8 },
  { header: 'Reviews', key: 'reviews', width: 10 },
  { header: 'Address', key: 'address', width: 32 },
  { header: 'Website', key: 'website', width: 28 },
  { header: 'Website Type', key: 'websiteType', width: 14 },
  { header: 'Website Quality', key: 'websiteQuality', width: 14 },
  { header: 'Google Maps Link', key: 'googleMapsUrl', width: 30 },
  { header: 'Priority', key: 'priority', width: 12 },
  { header: 'Contacted', key: 'contacted', width: 12 },
  { header: 'Follow-up Date', key: 'followUp', width: 14 },
  { header: 'Deal Status', key: 'dealStatus', width: 14 },
  { header: 'Notes', key: 'notes', width: 24 },
];

async function saveExcel(rows, filePath) {
  const wb = new ExcelJS.Workbook();
  const sheet = wb.addWorksheet('Leads');
  sheet.columns = COLUMNS;
  sheet.getRow(1).font = { bold: true };
  sheet.views = [{ state: 'frozen', ySplit: 1 }];

  rows.forEach((r, i) => {
    const row = sheet.addRow({ ...r, contacted: '', followUp: '', dealStatus: '', notes: '' });
    if (i % 2 === 1) {
      row.eachCell(cell => {
        cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFF3F3F3' } };
      });
    }
  });

  await wb.xlsx.writeFile(filePath);
}

function saveCsv(rows, filePath) {
  const headers = COLUMNS.map(c => c.header);
  const lines = [headers.join(',')];
  rows.forEach(r => {
    const line = COLUMNS.map(c => {
      const val = (r[c.key] ?? '').toString().replace(/"/g, '""');
      return `"${val}"`;
    }).join(',');
    lines.push(line);
  });
  fs.writeFileSync(filePath, lines.join('\n'), 'utf8');
}

module.exports = { saveExcel, saveCsv };
